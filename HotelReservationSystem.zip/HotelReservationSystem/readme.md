Instructions to run the HOTEL RESERVATIONS APPLICATION

Tech Stack for the application : Java, SpringBoot, Thymeleaf , MySQL.

Softwares Needed:
1. Java latest version
2. IDE like eclipse , sts , IntelliJ
3. SpringBoot plugin for the IDE
4. MySQL Server and MySQL Workbench

Once the softwares are installed, to run the application,
1. Run the SQL commands in src/main/resources/dbscripts/hotels.sql script to create the Hotels DB and the required tables
2. Run the SQL commands in src/main/resources/dbscripts/insertStatements.sql script to insert the data into tables. *** BE SURE TO UPDATE THE INSERT Statements with correct/latest data
3. Update the spring.datasource.url, spring.datasource.username and spring.datasource.password in application.properties file (/src/main/resources/application.properties).

Save all the changes and run the application.


URL's:

There are 2 flows to this application. 
1. As a CUSTOMER(GUEST) , a user will be able to search for hotels at location with the search criteria and make a reservation at the hotel
	HOME PAGE URL for CUSTOMER : http://localhost:8080/ 

2. As a EMPLOYEE, a user will be able to 

	a. HOTEL ACTIONS :
		i. Search for hotels
		ii. Add a new hotel
		iii. Update Hotel (eg: update hotel details, room details,...)
		
	b. RESERVATION ACTIONS :
		i. Search for Reservation 
		ii. Make a new Reservation
		iii. Cancel a Reservation
		
	c. EMPLOYEE ACTIONS :
		i. Search for Employee
		ii. Add a new Employee
		iii. Edit Employee(eg: update employee details, employment status,...)
	
	a. Search for hotels
	b. Add a new hotel

LOGIN PAGE URL for EMPLOYEE : http://localhost:8080/web/employeeLogin
LANDING PAGE(HOME SCREEN) URL for EMPLOYEE : http://localhost:8080/web/employeeLanding


** BE SURE TO INSERT DATA IN EMPLOYEES, HOTEL, ROOM_TYPE, ROOMS, RATES AND ROOM_TYPE_INVENTORY tables before you try to search/make any reservations.
package com.course.cs5200;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

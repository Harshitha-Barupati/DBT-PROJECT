package com.course.cs5200.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.cs5200.entity.Hotel;
import com.course.cs5200.entity.RoomType;
import com.course.cs5200.repository.HotelRepository;
import com.course.cs5200.repository.RoomTypeRepository;

/**
 * Service class for managing Room Type entities.
 */
@Service
public class RoomTypeService {
	
	private final RoomTypeRepository roomTypeRepository;
	
	@Autowired
    public RoomTypeService(RoomTypeRepository roomTypeRepository) {
        this.roomTypeRepository = roomTypeRepository;
    }
	
    public RoomType saveRoomType(RoomType roomType) {
        return roomTypeRepository.save(roomType);
    }

    public List<RoomType> getAllRoomTypes() {
        return roomTypeRepository.findAll();
    }

    public Optional<RoomType> getRoomTypeById(int id) {
        return roomTypeRepository.findById(id);
    }
    
    public RoomType updateRoomType(int id, RoomType updatedRoomType) {
    	
        Optional<RoomType> existingRoomType = roomTypeRepository.findById(id);
        RoomType roomType = existingRoomType.get();
        
        if (existingRoomType.isPresent()) {
        	roomType.setRoomType(updatedRoomType.getRoomType());
            roomTypeRepository.save(roomType);
        } else {
            throw new RuntimeException("RoomType not found");
        }
        
        return roomType;
    }
    
    public void deleteRoomType(int id) {
    	roomTypeRepository.deleteById(id);
    }

}

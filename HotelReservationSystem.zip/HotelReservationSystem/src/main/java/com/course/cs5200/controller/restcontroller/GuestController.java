package com.course.cs5200.controller.restcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.entity.Guest;
import com.course.cs5200.service.GuestService;

@RestController
@RequestMapping("/api/v1")
public class GuestController {

	
	private final GuestService guestService;

	@Autowired
	public GuestController(GuestService guestService) {
		this.guestService = guestService;
	}
	
	@GetMapping("/guest/{guestId}")
	public ResponseEntity<Guest> getGuestById(@PathVariable int guestId) {
		Optional<Guest> guest = guestService.getGuestById(guestId);
		return guest.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/guests")
	public ResponseEntity<List<Guest>> getAllGuests() {
		List<Guest> response = guestService.getAllGuests();
		return ResponseEntity.ok(response);
	}
	
	@PostMapping("/guest")
	public ResponseEntity<Guest> saveEmployee(@RequestBody Guest guest) {
		Guest response = guestService.saveGuest(guest);
		return ResponseEntity.ok(response);
	}

	@PutMapping("/guest/{guestId}")
	public ResponseEntity<Guest> updateEmployee(@PathVariable int guestId, @RequestBody Guest guest) {
		Guest updatedGuest = guestService.updateGuest(guestId, guest);
		return ResponseEntity.ok(updatedGuest);
	}

	@DeleteMapping("/guest/{guestId}")
	public ResponseEntity<String> deleteGuest(@PathVariable int guestId) {
		guestService.deleteGuest(guestId);
		return ResponseEntity.ok("Guest deleted successfully");
	}
	
}

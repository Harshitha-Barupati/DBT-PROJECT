package com.course.cs5200.controller.restcontroller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Guest;
import com.course.cs5200.entity.Reservation;
import com.course.cs5200.service.GuestService;
import com.course.cs5200.service.ReservationService;

@RestController
@RequestMapping("/api/v1/search")
public class SearchController {

	
	private final ReservationService reservationService;
	private final GuestService guestService;

	@Autowired
	public SearchController(ReservationService reservationService, GuestService guestService) {
		this.reservationService = reservationService;
		this.guestService = guestService;
	}
	
	
	/* RESERVATIONS */
	
	// Find reservations by roomTypeId , hotelId and start Date
	@GetMapping("/reservation/{hotelId}/{roomTypeId}/{startDate}")
	public ResponseEntity<List<Reservation>> getReservationsByHotelIdAndRoomTypeIdAndStartDate(@PathVariable int hotelId, 
			@PathVariable int roomTypeId, @PathVariable Date startDate){
		List<Reservation> response = reservationService.getReservationsByHotelIdAndRoomTypeIdAndStartDate(hotelId, roomTypeId, startDate);	
		return ResponseEntity.ok(response);
	}
	
		
	// Find reservations by hotelId and start Date
	@GetMapping("/reservation/{hotelId}/{startDate}")
	public ResponseEntity<List<Reservation>> getReservationsByHotelIdAndStartDate(@PathVariable int hotelId, 
			@PathVariable Date startDate){
		List<Reservation> response = reservationService.getReservationsByHotelIdAndStartDate(hotelId, startDate);
		return ResponseEntity.ok(response);
	}
	
	// Find reservations by hotelId , start Date , reservation status
	@GetMapping("/reservation/{hotelId}/{startDate}/{reservationStatus}")
	public ResponseEntity<List<Reservation>> getReservationsByHotelIdAndStartDateAndStatus(@PathVariable int hotelId, 
			@PathVariable Date startDate, @PathVariable String reservationStatus){
		List<Reservation> response = reservationService.getReservationsByHotelIdAndStartDateAndStatus(hotelId, startDate, reservationStatus);
		return ResponseEntity.ok(response);
	}
		
	
	// Find reservations by hotelId and guestId
	@GetMapping("/reservation/{hotelId}/{guestId}")
	public ResponseEntity<List<Reservation>> getReservationsByHotelIdAndGuestId(int hotelId, int guestId){
		List<Reservation> response = reservationService.getReservationsByHotelIdAndGuestId(hotelId, guestId);
		return ResponseEntity.ok(response);
	}
	
	// Find reservations by guestId
	@GetMapping("/reservation/{guestId}")
	public ResponseEntity<List<Reservation>> getReservationsByGuestId(@PathVariable int guestId){
		List<Reservation> response = reservationService.getReservationsByGuestId(guestId);
		return ResponseEntity.ok(response);
	}
	
	// Find reservations by guestId and start date
	@GetMapping("/reservation/{guestId}/{startDate}")
	public ResponseEntity<List<Reservation>> getReservationsByGuestIdAndStartDate(int guestId, Date startDate){
		List<Reservation> response = reservationService.getReservationsByGuestIdAndStartDate(guestId, startDate);
		return ResponseEntity.ok(response);
	}
	
	
	/* GUEST INFO */
	@GetMapping("/guest/{guestId}")
	public ResponseEntity<Guest> getGuestByGuestId(@PathVariable int guestId){
		Optional<Guest> response = guestService.getGuestById(guestId);
		return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/guest/{email}")
	public ResponseEntity<Guest> getGuestByEmail(@PathVariable String email){
		Optional<Guest> response = guestService.getGuestByEmail(email);
		return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/guest/{phoneNumber}")
	public ResponseEntity<Guest> getGuestByPhoneNumber(@PathVariable String phoneNumber){
		Optional<Guest> response = guestService.getGuestByPhoneNumber(phoneNumber);
		return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/guest/{firstName}/{lastName}")
	public ResponseEntity<Guest> getGuestByName(@PathVariable String firstName, @PathVariable String lastName){
		Optional<Guest> response = guestService.getGuestByName(firstName,lastName);
		return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
		
}

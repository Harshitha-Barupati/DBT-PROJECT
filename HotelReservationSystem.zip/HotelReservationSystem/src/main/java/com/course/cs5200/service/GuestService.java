package com.course.cs5200.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.entity.Guest;
import com.course.cs5200.repository.GuestAddressRepository;
import com.course.cs5200.repository.GuestRepository;

/**
 * Service class for managing Employee entities.
 */
@Service
public class GuestService {
	
	private final GuestRepository guestRepository;
	private final GuestAddressRepository guestAddressRepository;
	
	@Autowired
    public GuestService(GuestRepository guestRepository, GuestAddressRepository guestAddressRepository) {
        this.guestRepository = guestRepository;
        this.guestAddressRepository = guestAddressRepository;
    }
	
    public Guest saveGuest(Guest guest) {
        return guestRepository.save(guest);
    }

    public List<Guest> getAllGuests() {
        return guestRepository.findAll();
    }

    public Optional<Guest> getGuestById(int guestId) {
        return guestRepository.findById(guestId);
    }
    
    public Guest updateGuest(int guestId, Guest updatedGuest) {
        Optional<Guest> existingGuest = guestRepository.findById(guestId);
        
        Guest guest = existingGuest.get();
        
        if (existingGuest.isPresent()) {
        	
        	guest.setFirstName(updatedGuest.getFirstName());
        	guest.setLastName(updatedGuest.getLastName());
        	guest.setPhoneNumber(updatedGuest.getPhoneNumber());
        	guest.setEmail(updatedGuest.getEmail());
        	
        	guestRepository.save(guest);
            
        } else {
            throw new RuntimeException("Guest not found");
        }
        
        return guest;
    }
    
    public void deleteGuest(int guestId) {
    	guestRepository.deleteById(guestId);
    }
    
    public Optional<Guest> getGuestByEmail(String email) {
        return guestRepository.findByEmail(email);
    }
    
    public Optional<Guest> getGuestByPhoneNumber(String phoneNumber) {
        return guestRepository.findByPhoneNumber(phoneNumber);
    }
    
    public Optional<Guest> getGuestByName(String firstName, String lastName) {
        return guestRepository.findByFirstNameAndLastName(firstName, lastName);
    }

}

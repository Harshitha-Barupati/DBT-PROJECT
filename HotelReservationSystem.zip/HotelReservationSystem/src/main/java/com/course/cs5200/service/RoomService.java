package com.course.cs5200.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.cs5200.entity.Room;
import com.course.cs5200.repository.RoomRepository;

@Service
public class RoomService {
	
private final RoomRepository roomRepository;
	
	@Autowired
    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

	public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }
	
	public Optional<Room> getRoomByHotelIdAndRoomId(int hotelId, int roomId) {
        return Optional.ofNullable(roomRepository.getRoomByHotelIdAndRoomId(hotelId, roomId));
    }
	
	public List<Room> getAllAvailableRoomsByHotelId(int hotelId, boolean isAvailable) {
        return roomRepository.getAllAvailableRoomsByHotelIdAndIsAvailable(hotelId, isAvailable);
    }
	
	public List<Room> getAllRoomsByHotelId(int hotelId) {
        return roomRepository.getAllRoomsByHotelId(hotelId);
    }
	
	public void deleteRoomByHotelIdAndRoomId(int hotelId, int roomId) {
        roomRepository.deleteRoomByHotelIdAndRoomId(hotelId, roomId);
    }
	
	public Room updateRoom(int hotelId, int roomId, Room updatedRoom) {
		Optional<Room> existingRoom = getRoomByHotelIdAndRoomId(hotelId, roomId);

		Room room = existingRoom.get();

		if (existingRoom.isPresent()) {
			room.setRoomId(room.getRoomId());
			room.setHotelId(room.getHotelId());
			room.setFloor(room.getFloor());
			room.setAvailable(updatedRoom.isAvailable());
			room.setHasView(updatedRoom.isHasView());
			room.setViewDetails(updatedRoom.getViewDetails());

			roomRepository.save(room);
			
			

		} else {
			throw new RuntimeException("Hotel not found");
		}
		
		return room;

	}
	
	
}

package com.course.cs5200.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.RoomInventory;

import jakarta.persistence.LockModeType;

@Repository
public interface RoomInventoryRepository extends JpaRepository<RoomInventory, Integer>{
	
	// Find RoomInventory by roomTypeId , hotelId and inventory Date
	RoomInventory getRoomInventoryByHotelIdAndRoomTypeIdAndInventoryDate(int hotelId, int roomTypeId, Date inventoryDate);
    
    // Find RoomInventory by hotelId , Inventory Date 
	RoomInventory getRoomInventoryByHotelIdAndInventoryDate(int hotelId, Date rateDate);
    
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT i FROM RoomInventory i WHERE i.hotelId = :hotelId AND i.roomTypeId = :roomTypeId AND i.inventoryDate IN :inventoryDates")
    List<RoomInventory> findAndLockInventory(@Param("hotelId") int hotelId, @Param("roomTypeId") int roomTypeId,
    		@Param("inventoryDates") List<Date> inventoryDates);
    
	 @Modifying
	 @Query("UPDATE RoomInventory r SET r.totalReserved = r.totalReserved + :noOfRooms " +
	           "WHERE r.hotelId = :hotelId AND r.roomTypeId = :roomTypeId AND r.inventoryDate IN :inventoryDates")
	 int decrementInventoryForReservation(@Param("hotelId")int hotelId, @Param("roomTypeId")int roomTypeId, @Param("noOfRooms")int noOfRooms,
			 @Param("inventoryDates")List<Date> inventoryDates);

	 @Modifying
	 @Query("UPDATE RoomInventory r SET r.totalReserved = r.totalReserved - :noOfRooms " +
	           "WHERE r.hotelId = :hotelId AND r.roomTypeId = :roomTypeId AND r.inventoryDate IN :inventoryDates")
	 int incrementInventoryForReservation(@Param("hotelId")int hotelId, @Param("roomTypeId")int roomTypeId, @Param("noOfRooms")int noOfRooms,
			 @Param("inventoryDates")List<Date> inventoryDates);
  
}

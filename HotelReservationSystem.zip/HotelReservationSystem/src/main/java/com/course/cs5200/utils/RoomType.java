package com.course.cs5200.utils;

import java.util.List;

public enum RoomType {
	ALL (0),
	STANDARD (1),
	KING (2),
	SUITE (3);
	
	public final int roomTypeId;

    private RoomType(int roomTypeId) {
        this.roomTypeId = roomTypeId;
    }
    
    public int getRoomTypeId() {
    	return roomTypeId;
    }
    
    public static String getRoomType(int roomTypeId) {
    	String roomType = "";
    	
    	switch(roomTypeId) {
    	case 0:
    		roomType = "ALL";
    		break;
    	case 1:
    		roomType = "STANDARD";
    		break;
    	case 2:
    		roomType = "KING";
    		break;
    	case 3:
    		roomType = "SUITE";
    		break;
    	default:
    		roomType = "ALL";
    		break;
    	}
    	
    	
    	
    	return roomType;
    }
}


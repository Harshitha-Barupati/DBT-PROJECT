package com.course.cs5200.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "room_type_inventory")
public class RoomInventory {
	
	@Id
	private int hotelId;
	
	@Column(nullable = false)
	private int roomTypeId;
	
	@Column(nullable = false)
	private Date inventoryDate;
	
	@Column(nullable = false)
	private int totalInventory;
	
	@Column(nullable = false)
	private int totalReserved;
	
	@CreationTimestamp
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;
	
	@UpdateTimestamp
	@Column(name = "LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;
	
	// No-argument constructor
	public RoomInventory() {
	}

	public RoomInventory(int hotelId, int roomTypeId, Date inventoryDate, int totalInventory, int totalReserved,
			LocalDateTime createdDate, LocalDateTime lastUpdatedDate) {
		super();
		this.hotelId = hotelId;
		this.roomTypeId = roomTypeId;
		this.inventoryDate = inventoryDate;
		this.totalInventory = totalInventory;
		this.totalReserved = totalReserved;
		this.createdDate = createdDate;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(int roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public Date getInventoryDate() {
		return inventoryDate;
	}

	public void setInventoryDate(Date inventoryDate) {
		this.inventoryDate = inventoryDate;
	}

	public int getTotalInventory() {
		return totalInventory;
	}

	public void setTotalInventory(int totalInventory) {
		this.totalInventory = totalInventory;
	}

	public int getTotalReserved() {
		return totalReserved;
	}

	public void setTotalReserved(int totalReserved) {
		this.totalReserved = totalReserved;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
}

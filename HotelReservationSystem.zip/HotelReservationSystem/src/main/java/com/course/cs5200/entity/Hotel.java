package com.course.cs5200.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "hotel")
public class Hotel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hotelId;

	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String location;
	
	//@Column(nullable = false)
	//private int hotelAddressId;
	
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "hotel_address_id", referencedColumnName = "hotelAddressId", nullable = false, unique = true)
    private HotelAddress hotelAddress;
	
	//@Column(nullable = false)
	//private int hotelManagerId;
	
	@OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "hotel_manager_id", referencedColumnName = "employeeId")
    private Employee hotelManager;
	
	@Column(nullable = false)
	private int rooms;
	
	@CreationTimestamp
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;
	
	@UpdateTimestamp
	@Column(name = "LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;
	
	// No-argument constructor
	public Hotel() {
	}
	
	// All arguments constructor
	
	public Hotel(int hotelId, String name, String location, HotelAddress hotelAddress, Employee hotelManager,
			LocalDateTime createdDate, LocalDateTime lastUpdatedDate) {
		super();
		this.hotelId = hotelId;
		this.name = name;
		this.location = location;
		this.hotelAddress = hotelAddress;
		this.hotelManager = hotelManager;
		this.createdDate = createdDate;
		this.lastUpdatedDate = lastUpdatedDate;
	}


	// Getters and Setters
	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	public HotelAddress getHotelAddress() {
	    return hotelAddress;
	}

	public void setHotelAddress(HotelAddress hotelAddress) {
	    this.hotelAddress = hotelAddress;
	}
	
	public Employee getHotelManager() {
	    return hotelManager;
	}

	public void setHotelManager(Employee hotelManager) {
	    this.hotelManager = hotelManager;
	}

	public int getRooms() {
		return rooms;
	}

	public void setRooms(int rooms) {
		this.rooms = rooms;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}

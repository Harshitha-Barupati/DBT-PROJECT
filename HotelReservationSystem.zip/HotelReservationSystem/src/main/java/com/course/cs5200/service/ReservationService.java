package com.course.cs5200.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.course.cs5200.entity.Hotel;
import com.course.cs5200.entity.Reservation;
import com.course.cs5200.entity.RoomInventory;
import com.course.cs5200.model.ReservationVO;
import com.course.cs5200.repository.ReservationRepository;
import com.course.cs5200.repository.RoomInventoryRepository;
import com.course.cs5200.utils.HotelUtils;
import com.course.cs5200.utils.ReservationStatus;
import com.course.cs5200.utils.RoomType;

import io.micrometer.core.instrument.util.StringUtils;

/**
 * Service class for managing Room Type entities.
 */
@Service
public class ReservationService {
	
	private final HotelService hotelService;
	
	private final ReservationRepository reservationRepository;
	
	private final RoomInventoryRepository inventoryRepository;
	
	private final HotelUtils hotelUtils;
	
	@Autowired
    public ReservationService(HotelService hotelService, ReservationRepository reservationRepository, 
    		RoomInventoryRepository inventoryRepository, HotelUtils hotelUtils) {
		this.hotelService = hotelService;
        this.reservationRepository = reservationRepository;
        this.inventoryRepository = inventoryRepository;
        this.hotelUtils = hotelUtils;
    }
	
	public ReservationVO getReservation(ReservationVO reservation) {
		
		ReservationVO reservationVO = null;
		
		if(null != reservation) {
			
			// search by reservation id
			if(reservation.getReservationNo() > 0) {
				reservationVO = this.getReservationById(reservation.getReservationNo());
			} 
				
		}
    	
    	return reservationVO;
    	
    }
	
    public ReservationVO getReservationById(int id) {
    	Optional<Reservation> reservationEntity = reservationRepository.findById(id);
    	Optional<Hotel> hotelResult = hotelService.getHotelById(reservationEntity.get().getHotelId());
    	
    	ReservationVO confirmationVO = this.getReservationVO(reservationEntity.get(), hotelResult.get());
    	
    	return confirmationVO;
    	
    }
    
    public ReservationVO getReservationByGuestDetails(ReservationVO reservation) {
    	List<Reservation> reservationEntities;
    	
    	// look up by first name, last name and email
    	if(null != reservation.getEmail() && !StringUtils.isBlank(reservation.getEmail())) {
    		reservationEntities = reservationRepository.getReservationsByFirstNameAndLastNameAndEmail(
    				reservation.getFirstName(), reservation.getLastName(), reservation.getEmail());	
    	} 
    	else { // look up by first name, last name and phone number
    		reservationEntities = reservationRepository.getReservationsByFirstNameAndLastNameAndEmail(
    				reservation.getFirstName(), reservation.getLastName(), reservation.getPhone());	
    	}
    	
    	Optional<Hotel> hotelResult = hotelService.getHotelById(reservation.getHotelId());
    	
    	List<ReservationVO> reservations = new ArrayList<>();
    	
    	for(Reservation reservationEntity : reservationEntities) {
    		ReservationVO confirmationVO = this.getReservationVO(reservationEntity, hotelResult.get());
    		reservations.add(confirmationVO);
    		
    	}
    	
    	
    	
    	return null;
    	
    }
	
    /*
	@Transactional
    public ReservationVO addReservation(ReservationVO newReservation) {
		
		ReservationVO confirmationVO = new ReservationVO();
		
		Optional<Hotel> hotelResult = hotelService.getHotelById(newReservation.getHotelId());
		
		Reservation reservationEntity = getReservationEntity(newReservation);
		
        Reservation confirmation = reservationRepository.save(reservationEntity);
        
        // update room inventory
        if(null != confirmation) {
        	
        	List<Date> stayDates = hotelUtils.getDates(confirmation.getStartDate(), confirmation.getEndDate());
        	
        	// 1. Lock the inventory rows for the dates and room type
            inventoryRepository.findAndLockInventory(
                reservationEntity.getHotelId(),
                reservationEntity.getRoomTypeId(),
                stayDates
            );
            
            
        	
        	int result = inventoryRepository.decrementInventoryForReservation(confirmation.getHotelId(), confirmation.getRoomTypeId(),
        			confirmation.getNoOfRooms(), stayDates);
        	
        	if(result > 0) { // update the reservation status in the reservation table 
        		confirmation.setReservationStatus(ReservationStatus.CONFIRMED.name());
        		reservationRepository.save(confirmation);
        	}
        	
        	confirmationVO = this.getReservationVO(confirmation, hotelResult.get());
        }
        
        return confirmationVO;
    }
	*/
	
	@Transactional
    public ReservationVO addReservation(ReservationVO newReservation) {
		
		ReservationVO confirmationVO = new ReservationVO();
		
		Optional<Hotel> hotelResult = hotelService.getHotelById(newReservation.getHotelId());
		
		Reservation reservationEntity = getReservationEntity(newReservation);
		
        // Reservation confirmation = reservationRepository.save(reservationEntity);
        
		// Get the stay dates
        List<Date> stayDates = hotelUtils.getDates(reservationEntity.getStartDate(), reservationEntity.getEndDate());

        // Lock the inventory rows for the dates and room type
        List<RoomInventory> roomInventoryList = inventoryRepository.findAndLockInventory(
            reservationEntity.getHotelId(),
            reservationEntity.getRoomTypeId(),
            stayDates
        );

        // Save the reservation
        Reservation confirmation = reservationRepository.save(reservationEntity);

        // Update room inventory
        if (confirmation != null) {
            int result = inventoryRepository.decrementInventoryForReservation(
                confirmation.getHotelId(),
                confirmation.getRoomTypeId(),
                confirmation.getNoOfRooms(),
                stayDates
            );

            if (result > 0) {
                confirmation.setReservationStatus(ReservationStatus.CONFIRMED.name());
                reservationRepository.save(confirmation);
            }

            confirmationVO = this.getReservationVO(confirmation, hotelResult.get());
        }
        
        return confirmationVO;
    }
	
	@Transactional
    public ReservationVO saveReservation(ReservationVO reservation) {
		
		ReservationVO confirmationVO = new ReservationVO();
		
		Reservation reservationEntity = getReservationEntityForUpdate(reservation);
		
		Optional<Hotel> hotelResult = hotelService.getHotelById(reservationEntity.getHotelId());
		
        Reservation confirmation = reservationRepository.save(reservationEntity);
        
        // update room inventory
        if(null != confirmation) {
        	
        	confirmationVO = this.getReservationVO(confirmation, hotelResult.get());
        }
        
        return confirmationVO;
    }
	
	@Transactional
	public ReservationVO cancelReservationById(int reservationNo) {
    	Optional<Reservation> reservationEntity = reservationRepository.findById(reservationNo);
    	Optional<Hotel> hotelResult = hotelService.getHotelById(reservationEntity.get().getHotelId());
    	
    	Reservation confirmation = reservationEntity.get();
    	
    	ReservationVO cancellationVO = null;
    	
    	// update room inventory
        if(null != reservationEntity.get()) {
        	
        	List<Date> stayDates = hotelUtils.getDates(confirmation.getStartDate(), confirmation.getEndDate());
        	
        	int result = inventoryRepository.incrementInventoryForReservation(confirmation.getHotelId(), confirmation.getRoomTypeId(),
        			confirmation.getNoOfRooms(), stayDates);
        	
        	if(result > 0) { // update the reservation status in the reservation table 
        		confirmation.setReservationStatus(ReservationStatus.CANCELLED.name());
        		reservationRepository.save(confirmation);
        	}
        	
        	cancellationVO = this.getReservationVO(confirmation, hotelResult.get());
        }
    	
    	return cancellationVO;
    	
    }
	
    private Reservation getReservationEntity(ReservationVO reservationVO) {
    	Reservation reservation = new Reservation();
    	
    	reservation.setHotelId(reservationVO.getHotelId());
    	reservation.setRoomTypeId(reservationVO.getRoomTypeId());
    	reservation.setGuestId(reservationVO.getGuestId());
    	reservation.setFirstName(reservationVO.getFirstName());
    	reservation.setLastName(reservationVO.getLastName());
    	reservation.setEmail(reservationVO.getEmail());
    	reservation.setPhoneNumber(reservationVO.getPhone());
    	reservation.setStartDate(reservationVO.getCheckInDate());
    	reservation.setEndDate(reservationVO.getCheckOutDate());
    	reservation.setAmount(reservationVO.getPrice());
    	reservation.setNoOfRooms(reservationVO.getNoOfRooms());
    	reservation.setNoOfAdults(reservationVO.getNoOfAdults());
    	reservation.setNoOfChildren(reservationVO.getNoOfChildren());
    	
    	// set reservation status to pending initially
    	reservation.setReservationStatus(ReservationStatus.PENDING.name());
    	
		return reservation;
	}
    
    private Reservation getReservationEntityForUpdate(ReservationVO reservationVO) {
    	
    	Optional<Reservation> reservationEntity = reservationRepository.findById(reservationVO.getReservationNo());
    	
    	Reservation reservation = reservationEntity.get();
    	
    	reservation.setGuestId(reservationVO.getGuestId());
    	reservation.setFirstName(reservationVO.getFirstName());
    	reservation.setLastName(reservationVO.getLastName());
    	reservation.setEmail(reservationVO.getEmail());
    	reservation.setPhoneNumber(reservationVO.getPhone());
    	reservation.setNoOfAdults(reservationVO.getNoOfAdults());
    	reservation.setNoOfChildren(reservationVO.getNoOfChildren());
    	
		return reservation;
	}
    
    private ReservationVO getReservationVO(Reservation reservation, Hotel hotel) {
    	ReservationVO reservationVO = new ReservationVO();
    	
    	reservationVO.setReservationNo(reservation.getReservationId());
    	reservationVO.setHotelId(reservation.getHotelId());
    	reservationVO.setRoomTypeId(reservation.getRoomTypeId());
    	reservationVO.setRoomType(RoomType.getRoomType(reservation.getRoomTypeId()));
    	reservationVO.setGuestId(reservation.getGuestId());
    	reservationVO.setFirstName(reservation.getFirstName());
    	reservationVO.setLastName(reservation.getLastName());
    	reservationVO.setEmail(reservation.getEmail());
    	reservationVO.setPhone(reservation.getPhoneNumber());
    	reservationVO.setCheckInDate(reservation.getStartDate());
    	reservationVO.setCheckOutDate(reservation.getEndDate());
    	reservationVO.setPrice(reservation.getAmount());
    	reservationVO.setNoOfRooms(reservation.getNoOfRooms());
    	reservationVO.setNoOfAdults(reservation.getNoOfAdults());
    	reservationVO.setNoOfChildren(reservation.getNoOfChildren());
    	
    	reservationVO.setReservationStatus(reservation.getReservationStatus());
    	
    	reservationVO.setHotelName(hotel.getName());
    	reservationVO.setHotelLocation(hotel.getLocation());
    	reservationVO.setHotelAddressId(hotel.getHotelAddress().getHotelAddressId());
    	
		return reservationVO;
	}

	public Reservation saveReservation(Reservation reservation) {
        Reservation confirmation = reservationRepository.save(reservation);
        
        return confirmation;
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }


    
    public Reservation updateReservation(int id, Reservation updatedReservation) {
    	
        Optional<Reservation> existingReservation = reservationRepository.findById(id);
        Reservation reservation = existingReservation.get();
        
        if (existingReservation.isPresent()) {
        	
        	reservation.setStartDate(updatedReservation.getStartDate());
        	reservation.setEndDate(updatedReservation.getEndDate());
        	reservation.setReservationStatus(updatedReservation.getReservationStatus());
        	
        	reservationRepository.save(reservation);
        	
        } else {
            throw new RuntimeException("Reservation not found");
        }
        
        return reservation;
    }
    
    public void deleteReservation(int id) {
    	reservationRepository.deleteById(id);
    }
    
    // Find reservations by roomTypeId , hotelId and start Date
    public List<Reservation> getReservationsByHotelIdAndRoomTypeIdAndStartDate(int hotelId, int roomTypeId, Date startDate){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByHotelIdAndRoomTypeIdAndStartDate(hotelId, roomTypeId, startDate));
    	return reservations.get();
    }
    
    // Find reservations by hotelId and start Date
    public List<Reservation> getReservationsByHotelIdAndStartDate(int hotelId, Date startDate){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByHotelIdAndStartDate(hotelId, startDate));
    	return reservations.get();
    }
    
    // Find reservations by hotelId , start Date , reservation status
    public List<Reservation> getReservationsByHotelIdAndStartDateAndStatus(int hotelId, Date startDate, String reservationStatus){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByHotelIdAndStartDateAndReservationStatus(hotelId, startDate, reservationStatus));
    	return reservations.get();
    }
    
    // Find reservations by hotelId and guestId
    public List<Reservation> getReservationsByHotelIdAndGuestId(int hotelId, int guestId){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByHotelIdAndGuestId(hotelId, guestId));
    	return reservations.get();
    }
    
    // Find reservations by guestId
    public List<Reservation> getReservationsByGuestId(int guestId){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByGuestId(guestId));
    	return reservations.get();
    }
    
    // Find reservations by guestId and start date
    public List<Reservation> getReservationsByGuestIdAndStartDate(int guestId, Date startDate){
    	Optional<List<Reservation>> reservations = Optional.ofNullable(reservationRepository.getReservationsByGuestIdAndStartDate(guestId, startDate));
    	return reservations.get();
    }

}

package com.course.cs5200.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "rates")
public class Rate {
	
	@Id
	private int hotelId;
	
	@Column(nullable = false)
	private int roomTypeId;
	
	@Column(nullable = false)
	private Date rateDate;
	
	@Column(nullable = false)
	private float price;
	
	@Column(nullable = false)
	private boolean isActive;
	
	@CreationTimestamp
	@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;
	
	@UpdateTimestamp
	@Column(name = "LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;
	
	// No-argument constructor
	public Rate() {
	}
	
	// All arguments constructor
	public Rate(int hotelId, int roomTypeId, Date rateDate, float price, LocalDateTime createdDate,
			LocalDateTime lastUpdatedDate) {
		super();
		this.hotelId = hotelId;
		this.roomTypeId = roomTypeId;
		this.rateDate = rateDate;
		this.price = price;
		this.createdDate = createdDate;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	// Getters and Setters
	
	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public int getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(int roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public Date getRateDate() {
		return rateDate;
	}

	public void setRateDate(Date rateDate) {
		this.rateDate = rateDate;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}



	

}

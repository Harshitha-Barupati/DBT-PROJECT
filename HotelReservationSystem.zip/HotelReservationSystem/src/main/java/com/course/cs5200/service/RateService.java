package com.course.cs5200.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.cs5200.entity.Rate;
import com.course.cs5200.entity.RoomType;
import com.course.cs5200.repository.RateRepository;

/**
 * Service class for managing Room Type entities.
 */
@Service
public class RateService {
	
	private final RateRepository rateRepository;
	
	@Autowired
    public RateService(RateRepository rateRepository) {
        this.rateRepository = rateRepository;
    }
	
    public Rate saveRate(Rate rate) {
        return rateRepository.save(rate);
    }
    
    
    // Find rate by roomTypeId , hotelId and Rate Date
    public Rate getRatesByHotelIdAndRoomTypeIdAndRateDate(int hotelId, int roomTypeId, Date rateDate) {
    	return rateRepository.getRatesByHotelIdAndRoomTypeIdAndRateDate(hotelId, roomTypeId, rateDate);
    }
    
    // Find active rate by roomTypeId , hotelId , Rate Date and Active
    public Rate getActiveRatesByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, Date rateDate, boolean isActive ) {
    	return rateRepository.getActiveRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, rateDate, isActive);
    }
    
    // Find all rates by hotelId , Active and Rate Date
    public List<Rate> getAllActiveRatesByHotelIdAndRateDateAndIsActive(int hotelId, Date rateDate, boolean isActive){
    	return rateRepository.getAllActiveRatesByHotelIdAndRateDateAndIsActive(hotelId, rateDate, isActive);
    }
    
    // Find all rates by hotelId and Rate Date
    public List<Rate> getAllRatesByHotelIdAndRateDate(int hotelId, Date rateDate){
    	return rateRepository.getAllRatesByHotelIdAndRateDate(hotelId, rateDate);
    }
  
    // Update rate by hotelId , RoomTypeId, Active and Rate Date
    public Rate updateRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, boolean isActive, Rate updatedRate) {
    	Optional<Rate> existingRate = Optional.ofNullable(rateRepository.getActiveRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, updatedRate.getRateDate(), isActive));
    	
    	Rate rate = existingRate.get();
    	
    	if(existingRate.isPresent()) {
    		rate.setPrice(updatedRate.getPrice());
    		rate.setActive(updatedRate.isActive());
    		
    		rateRepository.save(rate);
    		
    	}
    	else {
			throw new RuntimeException("Rate not found for the date entered");
		}
    	
    	return rate;
    }
    
    // delete room by roomId and hotelId
    public void deleteRoomByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, Date rateDate, boolean isActive) {
    	rateRepository.deleteRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, rateDate, isActive);
    }
    

    public List<Rate> getAllRates() {
        return rateRepository.findAll();
    }

    public Optional<Rate> getRateById(int id) {
        return rateRepository.findById(id);
    }
    
    public Rate updateRate(int id, Rate updatedRate) {
    	
        Optional<Rate> existingRate = rateRepository.findById(id);
        Rate rate = existingRate.get();
        
        if (existingRate.isPresent()) {
        	rate.setPrice(updatedRate.getPrice());
        	rateRepository.save(rate);
        } else {
            throw new RuntimeException("Rate not found");
        }
        
        return rate;
    }
    
    public void deleteRate(int id) {
    	rateRepository.deleteById(id);
    }

}

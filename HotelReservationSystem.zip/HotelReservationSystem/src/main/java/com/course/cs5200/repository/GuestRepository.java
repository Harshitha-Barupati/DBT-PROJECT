package com.course.cs5200.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.Guest;

@Repository
public interface GuestRepository extends JpaRepository<Guest, Integer>{
	
	Optional<Guest> findByEmail(String email);
	Optional<Guest> findByPhoneNumber(String phoneNumber);
	Optional<Guest> findByFirstNameAndLastName(String firstName, String lastName);
	
}

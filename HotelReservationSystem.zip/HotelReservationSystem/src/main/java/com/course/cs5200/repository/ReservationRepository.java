package com.course.cs5200.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.Rate;
import com.course.cs5200.entity.Reservation;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Integer>{
	
	// Find reservations by FirstName, LastName and Email
    List<Reservation> getReservationsByFirstNameAndLastNameAndEmail(String firstName, String lastName, String email);
    
    // Find reservations by FirstName, LastName and Phone Number
    List<Reservation> getReservationsByFirstNameAndLastNameAndPhoneNumber(String firstName, String lastName, String phoneNumber);
	
	// Find reservations by roomTypeId , hotelId and start Date
    List<Reservation> getReservationsByHotelIdAndRoomTypeIdAndStartDate(int hotelId, int roomTypeId, Date startDate);
    
    // Find reservations by hotelId and start Date
    List<Reservation> getReservationsByHotelIdAndStartDate(int hotelId, Date startDate);
    
    // Find reservations by hotelId , start Date , reservation status
    List<Reservation> getReservationsByHotelIdAndStartDateAndReservationStatus(int hotelId, Date startDate, String reservationStatus);
    
    // Find reservations by hotelId and guestId
    List<Reservation> getReservationsByHotelIdAndGuestId(int hotelId, int guestId);
    
    // Find reservations by guestId
    List<Reservation> getReservationsByGuestId(int guestId);
    
    // Find reservations by guestId and start date
    List<Reservation> getReservationsByGuestIdAndStartDate(int guestId, Date startDate);
    
}

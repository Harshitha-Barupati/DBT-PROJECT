package com.course.cs5200.controller.webcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.model.EmployeeVO;
import com.course.cs5200.service.EmployeeService;

@Controller("WebEmployeeController")
@ResponseBody
@RequestMapping("/web/")
public class EmployeeController {

	
	private final EmployeeService employeeService;

	@Autowired
	public EmployeeController(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	
	
	@GetMapping("/employeeLogin")
	public ModelAndView getEmployeeLogin(Model model) {
		
		ModelAndView mav = new ModelAndView("employeeLogin");
		
		model.addAttribute("employeeLogin", new EmployeeVO());
		mav.addObject("model", model);
		
		return mav;
	}
	
	@PostMapping("/employeeLogin")
	public ModelAndView employeeLogin(@ModelAttribute EmployeeVO employeeVO, BindingResult bindingResult, Model model) {
		
		if (bindingResult.hasErrors()) {
	        //errors processing
			System.out.println("Employee Controller : Binding Errors in Employee Controller for Employee Login");
	    } 
		
		ModelAndView mav = new ModelAndView("employeeLanding");
		
		if(employeeVO.getEmployeeId() == 0) {
			System.out.println("Employee Controller : INVALID EMPLOYEE ID");
			return mav;
		}
		
		
		EmployeeVO employee = employeeService.getEmployeeProfile(employeeVO.getEmployeeId());
		
		if(null == employee) {
			employee = new EmployeeVO();
			System.out.println("Employee Controller : No Employee found with  EMPLOYEE ID");
		}
		
		model.addAttribute("employeeLogin", employee);
		mav.addObject("model", model);
		
		return mav;
	}
	
	@GetMapping("/employeeLanding")
	public ModelAndView getEmployeeHomePage(@ModelAttribute EmployeeVO employeeVO, Model model) {
		
		ModelAndView mav = new ModelAndView("employeeLanding");
		
		model.addAttribute("employeeLogin", employeeVO);
		mav.addObject("model", model);
		
		return mav;
	}
	

	// add new employee
	
	@GetMapping("/employee/add")
	public ModelAndView addEmployee(Model model) {
		
		ModelAndView mav = new ModelAndView("addEmployee");
		
		model.addAttribute("employee", new EmployeeVO());
		mav.addObject("model", model);
		
		return mav;
	}
	
	@PostMapping("/employee/add")
	public ModelAndView addEmployee(@ModelAttribute EmployeeVO employeeVO, Model model) {
		
		ModelAndView mav = new ModelAndView("employeeProfile");
		EmployeeVO employee = employeeService.saveEmployee(employeeVO);
		
		model.addAttribute("employee", employee);
		mav.addObject("model", model);
		
		return mav;
	}
	
	@GetMapping("/employee")
	public ModelAndView getEmployeeById(@RequestParam("employeeId") int employeeId, Model model) {
		ModelAndView mav = new ModelAndView("employeeProfile");
		EmployeeVO employee = employeeService.getEmployeeProfile(employeeId);
		model.addAttribute("employee", employee);
		mav.addObject("model", model);
		return mav;
	}
	
	@GetMapping("/employee/edit/{employeeId}")
	public ModelAndView getEditEmployeePage(@PathVariable("employeeId") int employeeId, Model model) {
		ModelAndView mav = new ModelAndView("editEmployee");
		EmployeeVO employee = employeeService.getEmployeeProfile(employeeId);
		model.addAttribute("employee", employee);
		mav.addObject("model", model);
		return mav;
	}
	
	@PostMapping("/employee/edit")
	public ModelAndView updateEmployee(@ModelAttribute EmployeeVO employeeVO, Model model) {
		ModelAndView mav = new ModelAndView("employeeProfile");
		EmployeeVO employee = employeeService.saveEmployee(employeeVO);
		model.addAttribute("employee", employee);
		mav.addObject("model", model);
		return mav;
	}
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> response = employeeService.getAllEmployees();
		return ResponseEntity.ok(response);
	}
	
	@PostMapping("/employee")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) {
		//Employee response = employeeService.saveEmployee(employee);
		return ResponseEntity.ok(null);
	}

	@PutMapping("/employee/{employeeId}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {
		Employee updatedEmployee = employeeService.updateEmployee(employeeId, employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employee/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int employeeId) {
		employeeService.deleteEmployee(employeeId);
		return ResponseEntity.ok("Employee deleted successfully");
	}
	
}

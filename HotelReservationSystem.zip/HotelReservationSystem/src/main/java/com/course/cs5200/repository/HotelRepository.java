package com.course.cs5200.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.course.cs5200.dto.SearchResultDTO;
import com.course.cs5200.entity.Hotel;
import com.course.cs5200.utils.RoomType;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Integer> {
    
	//Find hotels by location, 
    List<Hotel> findByLocationIgnoreCaseContaining(String location);
    
    // find hotels by search criteria - location, roomTypeId, checkin dates, adults, children
    @Query("SELECT DISTINCT new com.course.cs5200.dto.SearchResultDTO(h.hotelId, h.name, h.location, h.hotelAddress.hotelAddressId, MIN(r.price), " +
    "a.addressLine1, a.addressLine2, a.city, a.state, a.zipCode) " +
    "FROM Hotel h, HotelAddress a , Rate r, RoomInventory i, RoomType t " +
    "WHERE h.hotelId = i.hotelId AND r.hotelId = i.hotelId " +
    "AND h.hotelAddress.hotelAddressId = a.hotelAddressId " +
    "AND i.roomTypeId = r.roomTypeId AND i.roomTypeId = t.roomTypeId " +
    "AND i.inventoryDate = r.rateDate " +
    "AND i.totalReserved + :noOfRooms <= i.totalInventory " +
    "AND h.location like %:location% " +
    "AND i.inventoryDate IN :checkInDate " +
    "GROUP BY h.hotelId, h.name, h.location, h.hotelAddress.hotelAddressId, a.addressLine1, a.addressLine2, a.city, a.state, a.zipCode " + 
    "ORDER BY h.hotelId ASC ")
    List<SearchResultDTO> findHotelsBySearchCriteria(@Param("location")String location, @Param("roomTypes")List<RoomType> roomTypes, 
    		@Param("checkInDate") Date date, @Param("checkOutDate")Date date2, @Param("noOfRooms")int noOfRooms,  @Param("adults")int adults, @Param("children")int children);

    
    // find hotels by search criteria - location, roomTypeId, checkin dates, adults, children
    @Query("SELECT new com.course.cs5200.dto.SearchResultDTO(h.hotelId, h.name, h.location, h.hotelAddress.hotelAddressId, i.roomTypeId, t.roomType, r.price, " +
    "a.addressLine1, a.addressLine2, a.city, a.state, a.zipCode) " +
    "FROM Hotel h , HotelAddress a , Rate r, RoomInventory i, RoomType t " +
    "WHERE h.hotelId = i.hotelId AND r.hotelId = i.hotelId " + 
    "AND h.hotelAddress.hotelAddressId = a.hotelAddressId " +
    "AND i.roomTypeId = r.roomTypeId AND i.roomTypeId = t.roomTypeId " +
    "AND i.inventoryDate = r.rateDate " +
    "AND i.totalReserved + :noOfRooms <= i.totalInventory " +
    "AND h.hotelId = :hotelId " +
    "AND i.inventoryDate IN :checkInDate " +
    "ORDER BY h.hotelId ASC ")
    List<SearchResultDTO> findHotelsByIdAndSearchCriteria(@Param("hotelId")int hotelId, @Param("location")String location, @Param("roomTypes")List<RoomType> roomTypes, 
    		@Param("checkInDate") Date date, @Param("checkOutDate")Date date2, @Param("noOfRooms")int noOfRooms, @Param("adults")int adults, @Param("children")int children);
}

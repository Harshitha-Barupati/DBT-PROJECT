package com.course.cs5200.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.model.EmployeeVO;
import com.course.cs5200.repository.EmployeeRepository;

/**
 * Service class for managing Employee entities.
 */
@Service
public class EmployeeService {
	
	private final EmployeeRepository employeeRepository;
	
	@Autowired
    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }
	
	public EmployeeVO getEmployeeProfile(int employeeId) {
		Optional<Employee> result = this.getEmployeeById(employeeId);
		
		EmployeeVO employeeVO = new EmployeeVO();
		if(result.isPresent()) {
			Employee employee = result.get();
			
			employeeVO.setEmployeeId(employee.getEmployeeId());
			employeeVO.setFirstName(employee.getFirstName());
			employeeVO.setLastName(employee.getLastName());
			employeeVO.setDateOfBirth(employee.getDateOfBirth());
			employeeVO.setActive(employee.isActive());
			employeeVO.setDesignation(employee.getDesignation());
			employeeVO.setPhoneNumber(employee.getPhoneNumber());
			employeeVO.setEmail(employee.getEmail());
			employeeVO.setLocation(employee.getLocation());
			employeeVO.setPrimaryHotelId(employee.getPrimaryHotelId());
		}
		else 
		{
			return null;
		}
		
		return employeeVO;
	}
	
    private Employee getEmployeeEntity(EmployeeVO employeeVO) {
		Employee employeeEntity = new Employee();

		if(employeeVO.getEmployeeId() > 0) {
			employeeEntity.setEmployeeId(employeeVO.getEmployeeId());
		}
		
		employeeEntity.setFirstName(employeeVO.getFirstName());
		employeeEntity.setLastName(employeeVO.getLastName());
		employeeEntity.setDateOfBirth(employeeVO.getDateOfBirth());
		employeeEntity.setActive(employeeVO.isActive());
		employeeEntity.setDesignation(employeeVO.getDesignation());
		employeeEntity.setPhoneNumber(employeeVO.getPhoneNumber());
		employeeEntity.setEmail(employeeVO.getEmail());
		employeeEntity.setLocation(employeeVO.getLocation());
		employeeEntity.setPrimaryHotelId(employeeVO.getPrimaryHotelId());

		return employeeEntity;
	}
	
    public EmployeeVO saveEmployee(EmployeeVO employeeVO) {
    	Employee employeeEntity = this.getEmployeeEntity(employeeVO);
    	Employee response =  employeeRepository.save(employeeEntity);
    	EmployeeVO employee = getEmployeeProfile(response.getEmployeeId());
    	
    	return employee;
    }



	public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(int id) {
        return employeeRepository.findById(id);
    }
    
    public Employee updateEmployee(int id, Employee updatedEmployee) {
        Optional<Employee> existingEmployee = employeeRepository.findById(id);
        
        Employee employee = existingEmployee.get();
        
        if (existingEmployee.isPresent()) {
        	
        	employee.setFirstName(updatedEmployee.getFirstName());
        	employee.setLastName(updatedEmployee.getLastName());
        	employee.setDesignation(updatedEmployee.getDesignation());
        	employee.setPhoneNumber(updatedEmployee.getPhoneNumber());
        	employee.setEmail(updatedEmployee.getEmail());
        	employee.setPrimaryHotelId(updatedEmployee.getPrimaryHotelId());
        	
        	employee.setActive(updatedEmployee.isActive());
        	
            employeeRepository.save(employee);
            
        } else {
            throw new RuntimeException("Employee not found");
        }
        
        return employee;
    }
    
    public void deleteEmployee(int id) {
    	employeeRepository.deleteById(id);
    }

}

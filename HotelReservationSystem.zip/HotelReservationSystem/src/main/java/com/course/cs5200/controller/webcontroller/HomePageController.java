package com.course.cs5200.controller.webcontroller;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.course.cs5200.dto.SearchResultDTO;
import com.course.cs5200.entity.Hotel;
import com.course.cs5200.model.SearchVO;
import com.course.cs5200.service.HotelService;

@Controller("WebHomeController")
@ResponseBody
@RequestMapping("/")
public class HomePageController {

	private final HotelService hotelService;

	@Autowired
	public HomePageController(HotelService hotelService) {
		this.hotelService = hotelService;
	}

	
	@GetMapping("/")
	public ModelAndView showHomePage(Model model) {
		ModelAndView mav = new ModelAndView("home");
		model.addAttribute("search", new SearchVO());
		mav.addObject("model", model);
	
        return mav;
       
	}
	
	@PostMapping("/search")
	public ModelAndView searchHotels(@ModelAttribute SearchVO searchVO, BindingResult bindingResult, Model model) {
		
		if (bindingResult.hasErrors()) {
	        //errors processing
			System.out.println("Home Page Controller : Binding Errors in Hotel Controller for Save Hotel");
	    } 
		
		
		
		List<Hotel> hotels = hotelService.getHotelsByLocation(searchVO.getDestination());
		System.out.println("Home Page Controller : Hotels Search completed successfully");
		
		ModelAndView mav = new ModelAndView("searchHotels");
		model.addAttribute("search", searchVO);
		model.addAttribute("hotels", hotels);
		mav.addObject("model", model);
	
        return mav;
	}
	
	@PostMapping("/")
	public ModelAndView searchHotelsByCriteria(@ModelAttribute SearchVO searchVO, BindingResult bindingResult, Model model) {
		
		if (bindingResult.hasErrors()) {
	        //errors processing
			System.out.println("Home Page Controller : Binding Errors in Hotel Controller for Save Hotel");
	    } 
		
		
		
		List<SearchResultDTO> searchResults = hotelService.getHotelsBySearchCriteria(searchVO);
		System.out.println("Home Page Controller : Hotels Search completed successfully");
		
		
		ModelAndView mav = new ModelAndView("searchHotels");
		model.addAttribute("search", searchVO);
		model.addAttribute("searchResults", searchResults);
		model.addAttribute("hotels", new ArrayList());
		mav.addObject("model", model);
	
        return mav;
	}
	
	/**
	 * Get all hotels.
	 *
	 * @return the ResponseEntity with status 200 (OK) and with body of the list of
	 *         hotels
	 */

	@GetMapping("/hotels")
	public ModelAndView getAllHotels(Model model) {
		List<Hotel> hotels = hotelService.getAllHotels();
		//return ResponseEntity.ok(response);
		
		ModelAndView mav = new ModelAndView("hotels");
		model.addAttribute("hotels", hotels);
		mav.addObject("model", model);
	
        return mav;
	}
	
	/**
	 * Create a new hotel.
	 *
	 * @param hotel the hotel to create
	 * @return the ResponseEntity with status 200 (OK) and with body of the new
	 *         hotel
	 */

	@PostMapping("/hotels")
	public ModelAndView saveHotel(@ModelAttribute Hotel hotel, BindingResult bindingResult, Model model) {
		
		if (bindingResult.hasErrors()) {
	        //errors processing
			System.out.println("Hotel Controller : Binding Errors in Hotel Controller for Save Hotel");
	    } 
		
		Hotel response = hotelService.saveHotel(hotel);
		System.out.println("Hotel Controller : Hotel added successfully");
		
		//return ResponseEntity.ok(response);
		
		List<Hotel> hotels = hotelService.getAllHotels();
		
		ModelAndView mav = new ModelAndView("hotels");
		model.addAttribute("hotels", hotels);
		mav.addObject("model", model);
	
        return mav;
	}
	
	@PostMapping("/hotels/add")
	public ModelAndView addHotel(Model model) {
		System.out.println("Hotel Controller : Add Hotel");
		ModelAndView mav = new ModelAndView("addHotel");
		model.addAttribute("hotel", new Hotel());
		mav.addObject("model", model);
	
        return mav;
	}
	
	/**
	 * Get a hotel by ID.
	 *
	 * @param id the ID of the hotel to get
	 * @return the ResponseEntity with status 200 (OK) and with body of the hotel,
	 *         or with status 404 (Not Found) if the hotel does not exist
	 */
	@GetMapping("/hotels/{id}")
	public ResponseEntity<Hotel> getHotelById(@PathVariable int id) {
		Optional<Hotel> hotel = hotelService.getHotelById(id);
		return hotel.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	

	
	/**
	 * Update a hotel by ID.
	 *
	 * @param id    the ID of the hotel to update
	 * @param hotel the updated hotel
	 * @return the ResponseEntity with status 200 (OK) and with body of the updated
	 *         hotel, or with status 404 (Not Found) if the hotel does not exist
	 */

	@GetMapping(value="/hotels/update/{id}")
	public ModelAndView updateHotel(@PathVariable("id") int id, Model model) {
		Optional<Hotel> result = hotelService.getHotelById(id);
		
		ModelAndView mav = new ModelAndView("updateHotel");
		
		model.addAttribute("hotel", result.get());
		mav.addObject("model", model);
		return mav;
	}
	

	/**
	 * Update a hotel by ID.
	 *
	 * @param id    the ID of the hotel to update
	 * @param hotel the updated hotel
	 * @return the ResponseEntity with status 200 (OK) and with body of the updated
	 *         hotel, or with status 404 (Not Found) if the hotel does not exist
	 */

	@PutMapping(value="/hotels/{id}", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ModelAndView updateHotel(@ModelAttribute Hotel hotel, @PathVariable("id") int id, Model model) {
		Hotel updatedHotel = hotelService.updateHotel(id, hotel);
		System.out.println("Hotel Controller : Hotel updated successfully");
		
		//return ResponseEntity.ok(updatedHotel);
		return this.getAllHotels(model);
	}

	/**
	 * Delete a hotel by ID.
	 *
	 * @param id the ID of the hotel to delete
	 * @return the ResponseEntity with status 200 (OK) and with body of the message
	 *         "Hotel deleted successfully"
	 */
	@DeleteMapping("/hotels/{id}")
	public ModelAndView deleteHotel(@PathVariable("id") int id, Model model) {
		hotelService.deleteHotel(id);
		System.out.println("Hotel Controller : Hotel deleted successfully");
		//return ResponseEntity.ok("Hotel deleted successfully");
		return this.getAllHotels(model);
	}
}

package com.course.cs5200.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.Room;

@Repository
public interface RoomRepository extends JpaRepository<Room, Integer>{

	// Find room by roomId and hotelId
    Room getRoomByHotelIdAndRoomId(int hotelId, int roomId);
    
    // Find all available rooms by hotelId
    List<Room> getAllAvailableRoomsByHotelIdAndIsAvailable(int hotelId, boolean isAvailable);
    
	// Find rooms by hotelId
    List<Room> getAllRoomsByHotelId(int hotelId);
    
    
    // delete room by roomId and hotelId
    void deleteRoomByHotelIdAndRoomId(int hotelId, int roomId);

	
}

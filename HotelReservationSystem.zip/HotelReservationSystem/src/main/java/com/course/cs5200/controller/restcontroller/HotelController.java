package com.course.cs5200.controller.restcontroller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Hotel;
import com.course.cs5200.service.HotelService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/v1")
public class HotelController {

	private final HotelService hotelService;

	@Autowired
	public HotelController(HotelService hotelService) {
		this.hotelService = hotelService;
	}
	

	/**
	 * Get a hotel by ID.
	 *
	 * @param id the ID of the hotel to get
	 * @return the ResponseEntity with status 200 (OK) and with body of the hotel,
	 *         or with status 404 (Not Found) if the hotel does not exist
	 */
	@GetMapping("/hotels/{id}")
	public ResponseEntity<Hotel> getHotelById(@PathVariable int id) {
		Optional<Hotel> hotel = hotelService.getHotelById(id);
		return hotel.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	/**
	 * Get all hotels.
	 *
	 * @return the ResponseEntity with status 200 (OK) and with body of the list of
	 *         hotels
	 */
	
	@GetMapping("/hotels")
	public ResponseEntity<List<Hotel>> getAllHotels() {
		List<Hotel> response = hotelService.getAllHotels();
		return ResponseEntity.ok(response);
	}

	/**
	 * Create a new hotel.
	 *
	 * @param hotel the hotel to create
	 * @return the ResponseEntity with status 200 (OK) and with body of the new
	 *         hotel
	 */
	
	@PostMapping("/hotel")
	public ResponseEntity<Hotel> saveProduct(@RequestBody Hotel hotel) {
		Hotel response = hotelService.saveHotel(hotel);
		return ResponseEntity.ok(response);
	}

	

	/**
	 * Update a hotel by ID.
	 *
	 * @param id      the ID of the hotel to update
	 * @param hotel the updated hotel
	 * @return the ResponseEntity with status 200 (OK) and with body of the updated
	 *         hotel, or with status 404 (Not Found) if the hotel does not exist
	 */
	
	@PutMapping("/hotels/{id}")
	public ResponseEntity<Hotel> updateHotel(@PathVariable int id, @RequestBody Hotel hotel) {
		Hotel updatedProduct = hotelService.updateHotel(id, hotel);
		return ResponseEntity.ok(updatedProduct);
	}

	/**
	 * Delete a hotel by ID.
	 *
	 * @param id the ID of the hotel to delete
	 * @return the ResponseEntity with status 200 (OK) and with body of the message
	 *         "Hotel deleted successfully"
	 */
	@DeleteMapping("/hotels/{id}")
	public ResponseEntity<String> deleteHotel(@PathVariable int id) {
		hotelService.deleteHotel(id);
		return ResponseEntity.ok("Product deleted successfully");
	}
}

package com.course.cs5200.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.Rate;

@Repository
public interface RateRepository extends JpaRepository<Rate, Integer>{
	
	// Find rate by roomTypeId , hotelId and Rate Date
    Rate getRatesByHotelIdAndRoomTypeIdAndRateDate(int hotelId, int roomTypeId, Date rateDate);
    
    // Find rate by roomTypeId , hotelId , Rate Date and Active
    Rate getActiveRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, Date rateDate, boolean isActive);
    
    // Find all rates by hotelId , Active and Rate Date
    List<Rate> getAllActiveRatesByHotelIdAndRateDateAndIsActive(int hotelId, Date rateDate, boolean isActive);
    
    // Find all rates by hotelId and Rate Date
    List<Rate> getAllRatesByHotelIdAndRateDate(int hotelId, Date rateDate);
    
    // Find all rates by hotelId , Active and Rate Dates
    @Query("SELECT r FROM Rate r WHERE r.hotelId = :hotelId AND r.roomTypeId = :roomTypeId AND r.isActive = :isActive AND r.rateDate IN :rateDates")
    List<Rate> getActiveRatesByHotelIdAndRoomTypeIdAndIsActiveAndRateDateIn(@Param("hotelId") int hotelId, @Param("roomTypeId") int roomTypeId,
    	    @Param("isActive") boolean isActive, @Param("rateDates") List<Date> rateDates);
    
  
    // Native SQL Query to update  rates table to set active status by hotelId , room type id, Active , Rate Date
    //@Query(value = "UPDATE RATE SET  PRICE = ,  FROM students WHERE email = :email", nativeQuery = true)
    //Rate updateRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, Date rateDate, boolean isActive);
    
    // delete room by roomId and hotelId
	void deleteRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(int hotelId, int roomTypeId, Date rateDate, boolean isActive);
}

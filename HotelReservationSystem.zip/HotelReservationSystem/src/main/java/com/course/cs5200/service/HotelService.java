package com.course.cs5200.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.course.cs5200.dto.SearchResultDTO;
import com.course.cs5200.entity.Hotel;
import com.course.cs5200.entity.HotelAddress;
import com.course.cs5200.entity.Rate;
import com.course.cs5200.model.SearchVO;
import com.course.cs5200.repository.HotelAddressRepository;
import com.course.cs5200.repository.HotelRepository;
import com.course.cs5200.repository.RateRepository;
import com.course.cs5200.utils.HotelUtils;
import com.course.cs5200.utils.RoomType;

/**
 * Service class for managing Hotel entities.
 */
@Service
public class HotelService {
	
	private final HotelRepository hotelRepository;
	private final HotelAddressRepository hotelAddressRepository;
	private final RateRepository rateRepository;
	private final HotelUtils hotelUtils;
	
	@Autowired
    public HotelService(HotelRepository hotelRepository, HotelAddressRepository hotelAddressRepository,
    		RateRepository rateRepository, HotelUtils hotelUtils) {
        this.hotelRepository = hotelRepository;
        this.hotelAddressRepository = hotelAddressRepository;
        this.rateRepository = rateRepository;
        this.hotelUtils = hotelUtils;
    }
	
	
	/**
     * Save a Hotel.
     *
     * @param hotel the entity to save
     * @return the persisted entity
     */
    @Transactional
	public Hotel saveHotel(Hotel hotel) {
    	
    	Hotel newHotel = hotelRepository.save(hotel);
    	
        return newHotel;
    }

    /**
     * Get all the Hotels.
     *
     * @return the list of entities
     */
    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }
    
    /**
     * Get Hotels by Location the Hotel.
     *
     * @return the list of entities
     */
    public List<Hotel> getHotelsByLocation(String location) {
        return hotelRepository.findByLocationIgnoreCaseContaining(location);
    }
    
    /**
     * Get Hotels by Location the Hotel.
     *
     * @return the list of entities
     */
    public List<SearchResultDTO> getHotelsBySearchCriteria(SearchVO searchVO) {
    	
    	String location = searchVO.getDestination();
    	String checkinDate = searchVO.getCheckInDate().toString();
    	String checkOutDate = searchVO.getCheckOutDate().toString();
    	int adults = searchVO.getNoOfAdults() > 0 ? searchVO.getNoOfAdults() : 2;
    	int children = searchVO.getNoOfChildren();
    	int noOfRooms = searchVO.getNoOfRooms();
    	
    	int roomType = searchVO.getRoomType();
    	
    	List<RoomType> roomTypes = new ArrayList<>();
    	if(roomType == 0) {
    		roomTypes = new ArrayList<>(Arrays.asList(RoomType.values()));
    		roomTypes.remove(0);
    	} else {
    		for(RoomType type : RoomType.values()) {
    			if(type.getRoomTypeId() == roomType) {
    				
    				roomTypes.add(type);
    			}
    		}
    	}
    	
    	List<SearchResultDTO> searchResults =  hotelRepository.findHotelsBySearchCriteria(location, roomTypes, searchVO.getCheckInDate(),
        		searchVO.getCheckOutDate(), noOfRooms, adults, children);
    	
    	return searchResults;
    }
    
    /**
     * Get Hotels by Location the Hotel.
     *
     * @return the list of entities
     */
    public List<SearchResultDTO> getHotelsByIdAndSearchCriteria(int id, SearchVO searchVO) {
    	
    	String location = searchVO.getDestination();
    	String checkinDate = searchVO.getCheckInDate().toString();
    	String checkOutDate = searchVO.getCheckOutDate().toString();
    	int adults = searchVO.getNoOfAdults() > 0 ? searchVO.getNoOfAdults() : 2;
    	int children = searchVO.getNoOfChildren();
    	int noOfRooms = searchVO.getNoOfRooms();
    	
    	int roomType = searchVO.getRoomType();
    	
    	List<RoomType> roomTypes = new ArrayList<>();
    	if(roomType == 0) {
    		roomTypes = new ArrayList<>(Arrays.asList(RoomType.values()));
    		roomTypes.remove(0);
    	} else {
    		for(RoomType type : RoomType.values()) {
    			if(type.getRoomTypeId() == roomType) {
    				
    				roomTypes.add(type);
    			}
    		}
    	}
    	
        return hotelRepository.findHotelsByIdAndSearchCriteria(id, location, roomTypes, searchVO.getCheckInDate(),
        		searchVO.getCheckOutDate(), noOfRooms, adults, children);
    }

    /**
     * Get one product by ID.
     *
     * @param id the ID of the entity
     * @return the entity
     */
    public Optional<Hotel> getHotelById(int id) {
        return hotelRepository.findById(id);
    }
    
    /**
     * Update a Hotel.
     *
     * @param id the ID of the entity
     * @param updatedHotel the updated entity
     * @return the updated entity
     */
    public Hotel updateHotel(int id, Hotel updatedHotel) {
        Optional<Hotel> existingHotel = hotelRepository.findById(id);
        if (existingHotel.isPresent()) {
        	Hotel hotel = existingHotel.get();
        	hotel.setName(updatedHotel.getName());
        	hotel.setLocation(updatedHotel.getLocation());
        	hotel.getHotelAddress().setHotelAddressId(updatedHotel.getHotelAddress().getHotelAddressId());
        	hotel.getHotelManager().setEmployeeId(updatedHotel.getHotelManager().getEmployeeId());
            return hotelRepository.save(hotel);
        } else {
            throw new RuntimeException("Hotel not found");
        }
    }
    
    /**
     * Delete the Hotel by ID.
     *
     * @param id the ID of the entity
     */
    public void deleteHotel(int id) {
        hotelRepository.deleteById(id);
    }


	public float calculateRate(int hotelId, Date checkInDate, Date checkOutDate, 
			int roomTypeId, int noOfRooms) {
		
		List<Date> stayDates = hotelUtils.getDates(checkInDate, checkOutDate);
		
		List<Rate> ratesForStay = rateRepository.getActiveRatesByHotelIdAndRoomTypeIdAndIsActiveAndRateDateIn(hotelId, roomTypeId, true, stayDates);
		
		float totalRate = calculateRateForStay(ratesForStay);
		
		// multiplying the totalrate by no.ofRooms
		totalRate = totalRate * noOfRooms;
		
		return totalRate;
	}
	
	private float calculateRateForStay(List<Rate> ratesForStay) {
		
		float totalRate = 0;
		
		for(Rate rate : ratesForStay) {
			totalRate = totalRate + rate.getPrice();
		}
		
		return totalRate;
	}


	private List<Date> getDates(int noOfDays, Date checkInDate) {
		List<Date> stayDates = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(checkInDate);

        for (int i = 0; i < noOfDays; i++) {
            stayDates.add(calendar.getTime());
            calendar.add(Calendar.DATE, 1);
        }

        return stayDates;
	}




}

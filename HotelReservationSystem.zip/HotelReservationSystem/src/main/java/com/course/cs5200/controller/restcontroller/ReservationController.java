package com.course.cs5200.controller.restcontroller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Rate;
import com.course.cs5200.entity.Reservation;
import com.course.cs5200.model.ReservationVO;
import com.course.cs5200.service.ReservationService;

@RestController
@RequestMapping("/api/v1")
public class ReservationController {

	
	private final ReservationService reservationService;

	@Autowired
	public ReservationController(ReservationService reservationService) {
		this.reservationService = reservationService;
	}
	
	// Find reservation by reservationId
	@GetMapping("/reservation/{reservationId}")
	public ResponseEntity<ReservationVO> getReservationById(@PathVariable int reservationId){
		// Optional<Reservation> response = reservationService.getReservationById(reservationId);
		// return response.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
		ReservationVO confirmationVO = reservationService.getReservationById(reservationId);
		return ResponseEntity.ok(confirmationVO);
	}
	
	// create reservation
	@PostMapping("/reservation")
	public ResponseEntity<Reservation> saveReservation(@RequestBody Reservation reservation) {
		Reservation response = reservationService.saveReservation(reservation);
		return ResponseEntity.ok(response);
	}

	// update reservation
	@PutMapping("/reservation/{reservationId}")
	public ResponseEntity<Reservation> updateReservation(@PathVariable int reservationId, @RequestBody Reservation reservation) {
		Reservation updatedReservation = reservationService.updateReservation(reservationId, reservation);
		return ResponseEntity.ok(updatedReservation);
	}

	// delete reservation
	@DeleteMapping("/reservation/{reservationId}")
	public ResponseEntity<String> deleteReservation(@PathVariable int reservationId) {
		reservationService.deleteReservation(reservationId);
		return ResponseEntity.ok("Reservation deleted successfully");
	}
	
	// reservation history by guestId
	@GetMapping("/reservation/{guestId}")
	public ResponseEntity<List<Reservation>> getReservationsByGuestId(@PathVariable int guestId){
		List<Reservation> response = reservationService.getReservationsByGuestId(guestId);
		return ResponseEntity.ok(response);
	}
	
	
}

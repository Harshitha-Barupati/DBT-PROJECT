package com.course.cs5200.controller.restcontroller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Rate;
import com.course.cs5200.entity.RoomType;
import com.course.cs5200.service.RateService;

@RestController
@RequestMapping("/api/v1")
public class RateController {

	
	private final RateService rateService;

	@Autowired
	public RateController(RateService rateService) {
		this.rateService = rateService;
	}
	
	// /rates/{hotelId}/{roomTypeId}/{rateDate}/{isActive}
	
	// Rates by hotelId, roomTypeId and Date
	@GetMapping("/rates/{hotelId}/{roomTypeId}/{rateDate}")
	public ResponseEntity<Rate> getRatesByHotelIdAndRoomTypeIdAndRateDate(@PathVariable int hotelId,
			@PathVariable int roomTypeId, @PathVariable Date rateDate) {
		Optional<Rate> rate = Optional.ofNullable(rateService.getRatesByHotelIdAndRoomTypeIdAndRateDate(hotelId, roomTypeId, rateDate));
		return rate.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Rates by hotelId, roomTypeId, Date and Active
	@GetMapping("/rates/{hotelId}/{roomTypeId}/{rateDate}/{isActive}")
	public ResponseEntity<Rate> getActiveRatesByHotelIdAndRoomTypeIdAndRateDate(@PathVariable int hotelId,
			@PathVariable int roomTypeId, @PathVariable Date rateDate, @PathVariable boolean isActive) {
		Optional<Rate> rate = Optional.ofNullable(rateService.getActiveRatesByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, rateDate, true));
		return rate.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	// Rates by hotelId, Date and Active
	@GetMapping("/rates/{hotelId}/{rateDate}/{isActive}")
	public ResponseEntity<List<Rate>> getActiveRatesByHotelIdAndRateDate(@PathVariable int hotelId,
			@PathVariable Date rateDate) {
		Optional<List<Rate>> rate = Optional.ofNullable(rateService.getAllActiveRatesByHotelIdAndRateDateAndIsActive(hotelId, rateDate, true));
		return rate.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@PostMapping("/rates")
	public ResponseEntity<Rate> saveRate(@RequestBody Rate rate) {
		Rate response = rateService.saveRate(rate);
		return ResponseEntity.ok(response);
	}

	@PutMapping("/rates/{hotelId}/{roomTypeId}/{rateDate}")
	public ResponseEntity<Rate> updateRate(@PathVariable int hotelId, 
			@PathVariable int roomTypeId, @PathVariable Date rateDate, @RequestBody Rate rate) {
		Rate updatedRate = rateService.updateRateByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, true, rate);
		return ResponseEntity.ok(updatedRate);
	}

	@DeleteMapping("/rates/{hotelId}/{roomTypeId}/{rateDate}")
	public ResponseEntity<String> deleteRate(@PathVariable int hotelId, 
			@PathVariable int roomTypeId, @PathVariable Date rateDate) {
		rateService.deleteRoomByHotelIdAndRoomTypeIdAndRateDateAndIsActive(hotelId, roomTypeId, rateDate, true);
		return ResponseEntity.ok("Rate deleted successfully");
	}
}

package com.course.cs5200.controller.webcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.course.cs5200.dto.SearchResultDTO;
import com.course.cs5200.entity.Hotel;
import com.course.cs5200.entity.Reservation;
import com.course.cs5200.model.EmployeeVO;
import com.course.cs5200.model.ReservationVO;
import com.course.cs5200.model.SearchVO;
import com.course.cs5200.service.HotelService;
import com.course.cs5200.service.ReservationService;
import com.course.cs5200.utils.RoomType;

@Controller("WebReservationController")
@RestController
@RequestMapping("/web")
public class ReservationController {

	private final ReservationService reservationService;
	private final HotelService hotelService;

	@Autowired
	public ReservationController(ReservationService reservationService, HotelService hotelService) {
		this.reservationService = reservationService;
		this.hotelService = hotelService;
	}

	// Get Reservation Page for Hotel
	@GetMapping("/reserve/hotels/{id}/1")
	public ModelAndView getHotel(@PathVariable("id") int id, Model model) {

		ModelAndView mav = new ModelAndView("reserve");
		
		Optional<Hotel> result = hotelService.getHotelById(id);

		model.addAttribute("reservation", new ReservationVO());
		model.addAttribute("hotel", result.get());
		mav.addObject("model", model);

		return mav;

	}

	// Get Reservation Page for Hotel
	@GetMapping("/reserve/hotels/{id}")
	public ModelAndView getReservationPageForHotel(@ModelAttribute("search") SearchVO searchVO,
			@PathVariable("id") int id, Model model) {

		ModelAndView mav = new ModelAndView("reserve");

		Optional<Hotel> result = hotelService.getHotelById(id);
		List<SearchResultDTO> searchResults = hotelService.getHotelsByIdAndSearchCriteria(id, searchVO);

		model.addAttribute("reservation", this.getReservationVO(id, searchVO, result.get()));
		model.addAttribute("searchResults", searchResults);

		mav.addObject("model", model);

		return mav;
	}

	private ReservationVO getReservationVO(int id, SearchVO searchVO, Hotel hotel) {
		ReservationVO reservationVO = new ReservationVO();

		reservationVO.setHotelId(id);
		reservationVO.setDestination(searchVO.getDestination());
		reservationVO.setCheckInDate(searchVO.getCheckInDate());
		reservationVO.setCheckOutDate(searchVO.getCheckOutDate());
		reservationVO.setNoOfRooms(searchVO.getNoOfRooms());
		reservationVO.setNoOfAdults(searchVO.getNoOfAdults());
		reservationVO.setNoOfChildren(searchVO.getNoOfChildren());

		reservationVO.setHotelId(hotel.getHotelId());
		reservationVO.setHotelName(hotel.getName());
		reservationVO.setHotelLocation(hotel.getLocation());
		reservationVO.setHotelAddressId(hotel.getHotelAddress().getHotelAddressId());

		return reservationVO;
	}

	@PostMapping("/reserve/hotels/{id}/guest")
	public ModelAndView getHotel(@ModelAttribute("reservation") ReservationVO reservation, @PathVariable("id") int id,
			Model model) {

		ModelAndView mav = new ModelAndView("guestDetails");

		float totalRate = hotelService.calculateRate(id, reservation.getCheckInDate(), reservation.getCheckOutDate(),
				reservation.getRoomTypeId(), reservation.getNoOfRooms());

		reservation.setPrice(totalRate);

		// set hotelIdroomType in the reservation object
		reservation.setHotelId(id);
		reservation.setRoomType(RoomType.getRoomType(reservation.getRoomTypeId()));

		model.addAttribute("reservation", reservation);
		mav.addObject("model", model);

		return mav;

	}

	@PostMapping("/reserve/hotels/{id}/confirm")
	public ModelAndView confirmReservation(@ModelAttribute("reservation") ReservationVO reservation,
			@PathVariable("id") int id, Model model) {

		ModelAndView mav = new ModelAndView("confirmation");

		ReservationVO confirmationVO = reservationService.addReservation(reservation);

		model.addAttribute("confirmation", confirmationVO);
		mav.addObject("model", model);

		return mav;

	}
	
	@GetMapping("/reservation/search")
	public ModelAndView getEmployeeById(Model model) {
		
		ModelAndView mav = new ModelAndView("searchReservation");
		model.addAttribute("confirmation", new ReservationVO());
		mav.addObject("model", model);
		
		return mav;
	}

	// Find reservation by reservationId
	@PostMapping("/reservation/search")
	public ModelAndView getReservation(@ModelAttribute("confirmation") ReservationVO reservation, Model model) {

		ModelAndView mav = new ModelAndView("reservation");
		
		ReservationVO confirmationVO = reservationService.getReservation(reservation);

		model.addAttribute("confirmation", confirmationVO);
		mav.addObject("model", model);

		return mav;
	}
	
	// Edit reservation page for reservationId
	@GetMapping("/reservation/edit/{id}")
	public ModelAndView editReservation(@PathVariable("id") int id, @ModelAttribute("confirmation") ReservationVO reservation, Model model) {

		ModelAndView mav = new ModelAndView("editReservation");
		
		ReservationVO confirmationVO = reservationService.getReservationById(id);

		model.addAttribute("confirmation", confirmationVO);
		mav.addObject("model", model);

		return mav;
	}

	// Save changes to reservation for reservationId
	@PostMapping("/reservation/save")
	public ModelAndView saveReservation(@ModelAttribute("confirmation") ReservationVO reservation, Model model) {

		ModelAndView mav = new ModelAndView("reservation");
		
		ReservationVO confirmationVO = reservationService.saveReservation(reservation);

		model.addAttribute("confirmation", confirmationVO);
		mav.addObject("model", model);

		return mav;
	}
	
	// Cancel reservation by reservationId
	@PostMapping("/reservation/cancel/{id}")
	public ModelAndView cancelReservation(@PathVariable("id") int id, @ModelAttribute("confirmation") ReservationVO reservation, Model model) {

		ModelAndView mav = new ModelAndView("cancelReservation");
		
		ReservationVO confirmationVO = reservationService.cancelReservationById(id);

		model.addAttribute("confirmation", confirmationVO);
		mav.addObject("model", model);

		return mav;
	}	

	// create reservation
	@PostMapping("/reservation")
	public ResponseEntity<Reservation> saveReservation(@RequestBody Reservation reservation) {
		Reservation response = reservationService.saveReservation(reservation);
		return ResponseEntity.ok(response);
	}

	// update reservation
	@PutMapping("/reservation/{reservationId}")
	public ResponseEntity<Reservation> updateReservation(@PathVariable int reservationId,
			@RequestBody Reservation reservation) {
		Reservation updatedReservation = reservationService.updateReservation(reservationId, reservation);
		return ResponseEntity.ok(updatedReservation);
	}

	// delete reservation
	@DeleteMapping("/reservation/{reservationId}")
	public ResponseEntity<String> deleteReservation(@PathVariable int reservationId) {
		reservationService.deleteReservation(reservationId);
		return ResponseEntity.ok("Reservation deleted successfully");
	}

	// reservation history by guestId
	@GetMapping("/reservation/{guestId}")
	public ResponseEntity<List<Reservation>> getReservationsByGuestId(@PathVariable int guestId) {
		List<Reservation> response = reservationService.getReservationsByGuestId(guestId);
		return ResponseEntity.ok(response);
	}

}

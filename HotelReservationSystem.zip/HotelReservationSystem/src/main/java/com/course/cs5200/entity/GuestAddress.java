package com.course.cs5200.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "guest_address")
public class GuestAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int guestAddressId;
	
	@Column(nullable = false)
	private int guestId;
	
	@Column(nullable = false)
	private String addressLine1;
	
	@Column(nullable = true)
	private String addressLine2;
	
	@Column(nullable = false)
	private String city;
	
	@Column(nullable = false)
	private Date state;
	
	@Column(nullable = false)
	private String country;
	
	@Column(nullable = false)
	private String zipCode;
	
	@CreationTimestamp
	//@Column(name = "CREATED_DATE")
	private LocalDateTime createdDate;
	
	@UpdateTimestamp
	//@Column(name = "LAST_UPDATED_DATE")
	private LocalDateTime lastUpdatedDate;
	
	
	
	// Getters and Setters

	public int getGuestAddressId() {
		return guestAddressId;
	}

	public void setGuestAddressId(int guestAddressId) {
		this.guestAddressId = guestAddressId;
	}

	public int getGuestId() {
		return guestId;
	}

	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getState() {
		return state;
	}

	public void setState(Date state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDateTime lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
		
	

}

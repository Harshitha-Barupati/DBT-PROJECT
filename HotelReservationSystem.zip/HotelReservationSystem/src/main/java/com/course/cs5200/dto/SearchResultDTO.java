package com.course.cs5200.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;

public class SearchResultDTO {
	
	private int hotelId;

	private String name;
	
	private String location;
	
	private int hotelAddressId;
	
	private String addressLine1;
	
	private String addressLine2;
	
	private String city;
	
	private String state;
	
	private String zipCode;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date checkInDate;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date checkOutDate;
	
	private int roomTypeId;
	
	private String roomType;
	
	private int noOfAdults;
	
	private int noOfChildren;
	
	private float price;
	
	public SearchResultDTO() {
	}
	
	public SearchResultDTO(int hotelId, String name, String location, int hotelAddressId, int roomTypeId,
			String roomType, float price, String addressLine1, String addressLine2, String city, String state, String zipCode) {
		super();
		this.hotelId = hotelId;
		this.name = name;
		this.location = location;
		this.hotelAddressId = hotelAddressId;
		this.roomTypeId = roomTypeId;
		this.roomType = roomType;
		this.price = price;
		this.addressLine1 = addressLine1;
	    this.addressLine2 = addressLine2;
	    this.city = city;
	    this.state = state;
	    this.zipCode = zipCode;
	}
	
	public SearchResultDTO(int hotelId, String name, String location, int hotelAddressId, float price, 
			String addressLine1, String addressLine2, String city, String state, String zipCode) {
	    this.hotelId = hotelId;
	    this.name = name;
	    this.location = location;
	    this.hotelAddressId = hotelAddressId;
	    this.price = price;
	    this.addressLine1 = addressLine1;
	    this.addressLine2 = addressLine2;
	    this.city = city;
	    this.state = state;
	    this.zipCode = zipCode;
	}

	public SearchResultDTO(int hotelId, String name, String location, int hotelAddressId, String addressLine1,
			String addressLine2, String city, String state, String zipCode, Date checkInDate, Date checkOutDate,
			int roomTypeId, String roomType, int noOfAdults, int noOfChildren, float price) {
		super();
		this.hotelId = hotelId;
		this.name = name;
		this.location = location;
		this.hotelAddressId = hotelAddressId;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.roomTypeId = roomTypeId;
		this.roomType = roomType;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.price = price;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getHotelAddressId() {
		return hotelAddressId;
	}

	public void setHotelAddressId(int hotelAddressId) {
		this.hotelAddressId = hotelAddressId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Date getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(Date checkInDate) {
		this.checkInDate = checkInDate;
	}

	public Date getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(Date checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public int getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(int roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	

}

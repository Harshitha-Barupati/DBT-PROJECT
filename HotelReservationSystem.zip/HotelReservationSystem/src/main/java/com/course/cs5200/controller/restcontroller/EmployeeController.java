package com.course.cs5200.controller.restcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.service.EmployeeService;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {

	
	private final EmployeeService employeeService;

	@Autowired
	public EmployeeController(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@GetMapping("/employee/{employeeId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int employeeId) {
		Optional<Employee> employee = employeeService.getEmployeeById(employeeId);
		return employee.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> response = employeeService.getAllEmployees();
		return ResponseEntity.ok(response);
	}
	
//	@PostMapping("/employee")
//	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) {
//		Employee response = employeeService.saveEmployee(employee);
//		return ResponseEntity.ok(response);
//	}

	@PutMapping("/employee/{employeeId}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable int employeeId, @RequestBody Employee employee) {
		Employee updatedEmployee = employeeService.updateEmployee(employeeId, employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employee/{employeeId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable int employeeId) {
		employeeService.deleteEmployee(employeeId);
		return ResponseEntity.ok("Employee deleted successfully");
	}
	
}

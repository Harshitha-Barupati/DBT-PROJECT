package com.course.cs5200.utils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class HotelUtils {
	
	
	public List<Date> getDates(Date checkInDate, Date checkOutDate) {
		int noOfDays = 0;
		
		try {
			noOfDays = (int) daysBetween(checkInDate, checkOutDate);
		} catch (ParseException e) {
			System.out.println("HOTEL UTILS - getDates : Error calculating no.of days for the stay");
			e.printStackTrace();
		}
		List<Date> stayDates = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(checkInDate);

        for (int i = 0; i < noOfDays; i++) {
            stayDates.add(calendar.getTime());
            calendar.add(Calendar.DATE, 1);
        }

        return stayDates;
	}

	private long daysBetween(Date checkinDate, Date checkoutDate) throws ParseException {
        
		/* 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date checkin = sdf.parse(checkinDate);
        Date checkout = sdf.parse(checkoutDate);
        */

        long diffInMillis = checkoutDate.getTime() - checkinDate.getTime();
        // 86_400_000 = 1000 * 60 * 60 * 24 (milliseconds in a day)
        return diffInMillis / 86_400_000;
    }
}

package com.course.cs5200.controller.restcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.course.cs5200.entity.RoomType;
import com.course.cs5200.service.RoomTypeService;

@RestController
@RequestMapping("/api/v1")
public class RoomTypeController {

	
	private final RoomTypeService roomTypeService;

	@Autowired
	public RoomTypeController(RoomTypeService roomTypeService) {
		this.roomTypeService = roomTypeService;
	}
	
	
	@GetMapping("/rooms/type/{roomTypeId}")
	public ResponseEntity<RoomType> getRoomTypeById(@PathVariable int roomTypeId) {
		Optional<RoomType> roomType = roomTypeService.getRoomTypeById(roomTypeId);
		return roomType.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}
	
	@GetMapping("/rooms/type")
	public ResponseEntity<List<RoomType>> getAllRoomTypes(@PathVariable int hotelId) {
		List<RoomType> response = roomTypeService.getAllRoomTypes();
		return ResponseEntity.ok(response);
	}
	
	
	@PostMapping("/rooms/type")
	public ResponseEntity<RoomType> saveRoomType(@RequestBody RoomType roomType) {
		RoomType response = roomTypeService.saveRoomType(roomType);
		return ResponseEntity.ok(response);
	}

	@PutMapping("/rooms/type/{roomTypeId}")
	public ResponseEntity<RoomType> updateRoomType(@PathVariable int roomTypeId, @RequestBody RoomType roomType) {
		RoomType updatedRoomType = roomTypeService.updateRoomType(roomTypeId, roomType);
		return ResponseEntity.ok(updatedRoomType);
	}

	@DeleteMapping("/rooms/type/{roomTypeId}")
	public ResponseEntity<String> deleteRoom(@PathVariable int roomTypeId) {
		roomTypeService.deleteRoomType(roomTypeId);
		return ResponseEntity.ok("RoomType deleted successfully");
	}
}

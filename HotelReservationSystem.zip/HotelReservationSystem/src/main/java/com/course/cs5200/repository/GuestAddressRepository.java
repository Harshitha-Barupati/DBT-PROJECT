package com.course.cs5200.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.GuestAddress;

@Repository
public interface GuestAddressRepository extends JpaRepository<GuestAddress, Integer>{
	
}

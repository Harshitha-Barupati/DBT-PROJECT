package com.course.cs5200.utils;

public enum ReservationStatus {
	
	PENDING,
	CONFIRMED,
	CANCELLED;

}

package com.course.cs5200.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.course.cs5200.entity.Employee;
import com.course.cs5200.entity.Room;
import com.course.cs5200.entity.RoomType;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
}
